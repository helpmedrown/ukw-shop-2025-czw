﻿using Microsoft.EntityFrameworkCore;
using UKW_sklep_czw.Models;

namespace UKW_sklep_czw.DAL
{
    public class FilmsContext : DbContext
    {
        public DbSet<Category> Categories { get; set; }
        public DbSet<Film> Films { get; set; }

        public FilmsContext(DbContextOptions options) : base(options) 
        {
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            var categories = new List<Category>()
            {
                new Category { CategoryId = 1, Name = "Akcja", Description = "Filmy pełne emocji, z dynamicznymi scenami walki i pościgów." },
                new Category { CategoryId = 2, Name = "Komedia", Description = "Filmy pełne humoru i zabawnych sytuacji." },
                new Category { CategoryId = 3, Name = "Dramat", Description = "Filmy o głębokich emocjach, które poruszają trudne tematy." },
                new Category { CategoryId = 4, Name = "Horror", Description = "Filmy, które mają na celu wywołać strach i niepokój." },
                new Category { CategoryId = 5, Name = "Romans", Description = "Filmy o miłości i relacjach międzyludzkich." },
                new Category { CategoryId = 6, Name = "Przygodowy", Description = "Filmy z elementami przygód, które często zabierają widza do egzotycznych miejsc." },
                new Category { CategoryId = 7, Name = "Sci-Fi", Description = "Filmy o tematyce naukowej i futurystycznej." },
                new Category { CategoryId = 8, Name = "Animacja", Description = "Filmy animowane, zarówno dla dzieci, jak i dorosłych." },
                new Category { CategoryId = 9, Name = "Fantasy", Description = "Filmy, które przenoszą widza do światów pełnych magii i fantastycznych stworzeń." },
                new Category { CategoryId = 10, Name = "Dokumentalny", Description = "Filmy, które przedstawiają rzeczywiste wydarzenia i historie." }
            };

            var films = new List<Film>()
            {
                new Film { FilmId = 1, Title = "Die Hard", Director = "John McTiernan", Description = "Classic action movie.", Price = 19.99m, CategoryId = 1 },
                new Film { FilmId = 2, Title = "Mad Max: Fury Road", Director = "George Miller", Description = "High-octane action film set in a post-apocalyptic world.", Price = 24.99m, CategoryId = 1 },
                new Film { FilmId = 3, Title = "The Hangover", Director = "Todd Phillips", Description = "A wild comedy about a bachelor party gone wrong.", Price = 14.99m, CategoryId = 2 },
                new Film { FilmId = 4, Title = "Superbad", Director = "Greg Mottola", Description = "A hilarious teen comedy about two high schoolers.", Price = 12.99m, CategoryId = 2 },
                new Film { FilmId = 5, Title = "The Shawshank Redemption", Director = "Frank Darabont", Description = "A gripping drama about hope and friendship in prison.", Price = 29.99m, CategoryId = 3 },
                new Film { FilmId = 6, Title = "Forrest Gump", Director = "Robert Zemeckis", Description = "A drama following the extraordinary life of Forrest Gump.", Price = 19.99m, CategoryId = 3 },
                new Film { FilmId = 7, Title = "The Exorcist", Director = "William Friedkin", Description = "A chilling horror film about a young girl possessed by a demon.", Price = 22.99m, CategoryId = 4 },
                new Film { FilmId = 8, Title = "Get Out", Director = "Jordan Peele", Description = "A social horror film with intense psychological elements.", Price = 19.99m, CategoryId = 4 },
                new Film { FilmId = 9, Title = "The Notebook", Director = "Nick Cassavetes", Description = "A romantic drama about a couple's love story.", Price = 17.99m, CategoryId = 5 },
                new Film { FilmId = 10, Title = "Pride and Prejudice", Director = "Joe Wright", Description = "A romantic drama based on Jane Austen's novel.", Price = 16.99m, CategoryId = 5 },
                new Film { FilmId = 11, Title = "Indiana Jones: Raiders of the Lost Ark", Director = "Steven Spielberg", Description = "An adventure movie about an archaeologist seeking ancient treasures.", Price = 18.99m, CategoryId = 6 },
                new Film { FilmId = 12, Title = "Jurassic Park", Director = "Steven Spielberg", Description = "A thrilling adventure with dinosaurs and science fiction elements.", Price = 19.99m, CategoryId = 6 },
                new Film { FilmId = 13, Title = "Star Wars: A New Hope", Director = "George Lucas", Description = "A sci-fi epic set in a galaxy far, far away.", Price = 29.99m, CategoryId = 7 },
                new Film { FilmId = 14, Title = "Blade Runner", Director = "Ridley Scott", Description = "A sci-fi noir film exploring the nature of humanity.", Price = 24.99m, CategoryId = 7 },
                new Film { FilmId = 15, Title = "Toy Story", Director = "John Lasseter", Description = "An animated movie about the adventures of toys when their owners are away.", Price = 14.99m, CategoryId = 8 },
                new Film { FilmId = 16, Title = "Shrek", Director = "Andrew Adamson", Description = "An animated comedy featuring an ogre on a quest to save a princess.", Price = 12.99m, CategoryId = 8 },
                new Film { FilmId = 17, Title = "The Lord of the Rings: The Fellowship of the Ring", Director = "Peter Jackson", Description = "A fantasy epic about a journey to destroy a powerful ring.", Price = 29.99m, CategoryId = 9 },
                new Film { FilmId = 18, Title = "Harry Potter and the Sorcerer's Stone", Director = "Chris Columbus", Description = "A magical story about a young wizard's first year at Hogwarts.", Price = 24.99m, CategoryId = 9 },
                new Film { FilmId = 19, Title = "13th", Director = "Ava DuVernay", Description = "A documentary about race, justice, and mass incarceration in America.", Price = 9.99m, CategoryId = 10 },
                new Film { FilmId = 20, Title = "Won't You Be My Neighbor?", Director = "Morgan Neville", Description = "A documentary about the life and legacy of Fred Rogers.", Price = 12.99m, CategoryId = 10 }
            };

            modelBuilder.Entity<Category>().HasData(categories);
            modelBuilder.Entity<Film>().HasData(films);
        }
    }
}
