﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UKW_sklep_czw.Migrations
{
    public partial class NewData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryId", "Description", "Name" },
                values: new object[,]
                {
                    { 1, "Filmy pełne emocji, z dynamicznymi scenami walki i pościgów.", "Akcja" },
                    { 2, "Filmy pełne humoru i zabawnych sytuacji.", "Komedia" },
                    { 3, "Filmy o głębokich emocjach, które poruszają trudne tematy.", "Dramat" },
                    { 4, "Filmy, które mają na celu wywołać strach i niepokój.", "Horror" },
                    { 5, "Filmy o miłości i relacjach międzyludzkich.", "Romans" },
                    { 6, "Filmy z elementami przygód, które często zabierają widza do egzotycznych miejsc.", "Przygodowy" },
                    { 7, "Filmy o tematyce naukowej i futurystycznej.", "Sci-Fi" },
                    { 8, "Filmy animowane, zarówno dla dzieci, jak i dorosłych.", "Animacja" },
                    { 9, "Filmy, które przenoszą widza do światów pełnych magii i fantastycznych stworzeń.", "Fantasy" },
                    { 10, "Filmy, które przedstawiają rzeczywiste wydarzenia i historie.", "Dokumentalny" }
                });

            migrationBuilder.InsertData(
                table: "Films",
                columns: new[] { "FilmId", "CategoryId", "Description", "Director", "Price", "Title" },
                values: new object[,]
                {
                    { 1, 1, "Classic action movie.", "John McTiernan", 19.99m, "Die Hard" },
                    { 2, 1, "High-octane action film set in a post-apocalyptic world.", "George Miller", 24.99m, "Mad Max: Fury Road" },
                    { 3, 2, "A wild comedy about a bachelor party gone wrong.", "Todd Phillips", 14.99m, "The Hangover" },
                    { 4, 2, "A hilarious teen comedy about two high schoolers.", "Greg Mottola", 12.99m, "Superbad" },
                    { 5, 3, "A gripping drama about hope and friendship in prison.", "Frank Darabont", 29.99m, "The Shawshank Redemption" },
                    { 6, 3, "A drama following the extraordinary life of Forrest Gump.", "Robert Zemeckis", 19.99m, "Forrest Gump" },
                    { 7, 4, "A chilling horror film about a young girl possessed by a demon.", "William Friedkin", 22.99m, "The Exorcist" },
                    { 8, 4, "A social horror film with intense psychological elements.", "Jordan Peele", 19.99m, "Get Out" },
                    { 9, 5, "A romantic drama about a couple's love story.", "Nick Cassavetes", 17.99m, "The Notebook" },
                    { 10, 5, "A romantic drama based on Jane Austen's novel.", "Joe Wright", 16.99m, "Pride and Prejudice" },
                    { 11, 6, "An adventure movie about an archaeologist seeking ancient treasures.", "Steven Spielberg", 18.99m, "Indiana Jones: Raiders of the Lost Ark" },
                    { 12, 6, "A thrilling adventure with dinosaurs and science fiction elements.", "Steven Spielberg", 19.99m, "Jurassic Park" },
                    { 13, 7, "A sci-fi epic set in a galaxy far, far away.", "George Lucas", 29.99m, "Star Wars: A New Hope" },
                    { 14, 7, "A sci-fi noir film exploring the nature of humanity.", "Ridley Scott", 24.99m, "Blade Runner" },
                    { 15, 8, "An animated movie about the adventures of toys when their owners are away.", "John Lasseter", 14.99m, "Toy Story" },
                    { 16, 8, "An animated comedy featuring an ogre on a quest to save a princess.", "Andrew Adamson", 12.99m, "Shrek" },
                    { 17, 9, "A fantasy epic about a journey to destroy a powerful ring.", "Peter Jackson", 29.99m, "The Lord of the Rings: The Fellowship of the Ring" },
                    { 18, 9, "A magical story about a young wizard's first year at Hogwarts.", "Chris Columbus", 24.99m, "Harry Potter and the Sorcerer's Stone" },
                    { 19, 10, "A documentary about race, justice, and mass incarceration in America.", "Ava DuVernay", 9.99m, "13th" },
                    { 20, 10, "A documentary about the life and legacy of Fred Rogers.", "Morgan Neville", 12.99m, "Won't You Be My Neighbor?" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 13);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 14);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 15);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 16);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 17);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 18);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 19);

            migrationBuilder.DeleteData(
                table: "Films",
                keyColumn: "FilmId",
                keyValue: 20);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 10);
        }
    }
}
