﻿using System.Diagnostics;
using System.Reflection.Metadata.Ecma335;
using Microsoft.AspNetCore.Mvc;
using UKW_sklep_czw.DAL;
using UKW_sklep_czw.Models;

namespace UKW_sklep_czw.Controllers
{
    public class HomeController : Controller
    {
        FilmsContext _filmsContext;

        public HomeController(FilmsContext filmsContext)
        {
            _filmsContext = filmsContext;
        }



        public IActionResult Index()
        {
            var kategorie = _filmsContext.Categories.ToList();

            return View(kategorie);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult footerSites(string viewName)
        {
            return View(viewName);
        }

        
    }
}
